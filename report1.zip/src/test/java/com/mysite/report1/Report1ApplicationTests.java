package com.mysite.report1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Report1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
